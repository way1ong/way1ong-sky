import csv,glob,collections,subprocess,time,os,sys
items=collections.defaultdict(list)
for f in glob.glob('data/v_*.csv'):
    for r in csv.DictReader(open(f)): items[r['s']].append(float(r['m']))
ids=sorted({s.rsplit('/',1)[-1] for s,v in items.items() if min(v)<=6.5}, key=lambda q:int(q[1:]))
print('ids',len(ids)); sys.stdout.flush()
B=400
for n in range(0,len(ids),B):
    f=f'data/det_{n//B:03d}.csv'
    if os.path.exists(f):
        s=open(f).read()
        if s.startswith('s,') and 'Thread.run' not in s: continue
    vals=' '.join('wd:'+q for q in ids[n:n+B])
    q=f'''SELECT ?s ?ra ?dec ?inst ?con ?parent ?en ?uk ?hu WHERE {{
  VALUES ?s {{ {vals} }}
  OPTIONAL {{ ?s wdt:P6257 ?ra }}
  OPTIONAL {{ ?s wdt:P6258 ?dec }}
  OPTIONAL {{ ?s wdt:P31 ?inst }}
  OPTIONAL {{ ?s wdt:P59 ?con }}
  OPTIONAL {{ ?s wdt:P361 ?parent }}
  OPTIONAL {{ ?s rdfs:label ?en FILTER(LANG(?en) = "en") }}
  OPTIONAL {{ ?s rdfs:label ?uk FILTER(LANG(?uk) = "uk") }}
  OPTIONAL {{ ?s rdfs:label ?hu FILTER(LANG(?hu) = "hu") }}
}}'''
    open('tools/_det.rq','w').write(q)
    for attempt in range(5):
        r=subprocess.run(['curl','-sS','-A','star-map-research/0.1 (generic client)','-H','Accept: text/csv','--max-time','120','-o',f,'-w','%{http_code}','--data-urlencode','query@tools/_det.rq','https://query.wikidata.org/sparql'],capture_output=True,text=True)
        s=open(f).read() if os.path.exists(f) else ''
        ok=r.stdout.strip()=='200' and s.startswith('s,') and 'Thread.run' not in s
        print(n,r.stdout.strip(),s.count('\n')-1,'ok' if ok else 'RETRY'); sys.stdout.flush()
        time.sleep(20 if ok else 60)
        if ok: break
print('done')
