import csv,json,os,sys
from collections import OrderedDict
S=sys.argv[1]; repo=sys.argv[2]
fig=json.load(open(f'{repo}/src/data/constellations.json'))['figures']
rows=[r for r in csv.DictReader(open(f'{S}/queue/02-const.csv')) if r['abbr']]
extra=f'{S}/queue/05b-aricnc.csv'
if os.path.exists(extra) and open(extra).read().startswith('c,'):
    for r in csv.DictReader(open(extra)):
        abbr=r.get('abbr') or {'Aries':'Ari','Cancer':'Cnc'}[r['name']]
        rows.append({'abbr':abbr,'en':r['name'],'uk':r['uk'],'hu':r['hu']})
by={r['abbr']:r for r in rows}
strip=lambda s: s.replace(' csillagkép','').strip()
out={'en':OrderedDict(),'uk':OrderedDict(),'hu':OrderedDict()}
missing=[]
for k in sorted(fig):
    r=by.get(k)
    if not r or not r['en'] or not r['uk'] or not r['hu']: missing.append(k); continue
    out['en'][k]=r['en']; out['uk'][k]=r['uk']; out['hu'][k]=strip(r['hu'])
for lang,v in out.items():
    p=f'{repo}/src/i18n/{lang}.json'
    d=json.load(open(p,encoding='utf-8'),object_pairs_hook=OrderedDict)
    d['sky']['constellations']=v
    open(p,'w',encoding='utf-8').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('named',len(out['en']),'missing',missing)
