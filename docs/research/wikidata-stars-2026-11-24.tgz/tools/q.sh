#!/bin/sh
# q.sh <name> <sparql file>
curl -sS -A "star-map-research/0.1 (generic client)" -H "Accept: text/csv" --max-time 120 -o "data/$1.csv" -w "%{http_code} %{size_download}\n" --data-urlencode "query@$2" https://query.wikidata.org/sparql
