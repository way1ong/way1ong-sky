import subprocess,sys,time,os
edges=[-2.0,3.0,4.0,4.5,5.0,5.3,5.6,5.8,6.0,6.15,6.3,6.4,6.5,6.6]
for a,b in zip(edges,edges[1:]):
    f=f'data/v_{a}_{b}.csv'
    if os.path.exists(f):
        s=open(f).read()
        if s.startswith('s,') and 'Thread.run' not in s and 'timeout' not in s: print(a,b,'cached',s.count('\n')-1); continue
    q=f'''SELECT ?s ?m ?rank WHERE {{
  ?st ps:P1215 ?m . hint:Prior hint:rangeSafe true .
  FILTER(?m >= {a} && ?m < {b})
  ?st pq:P1227 wd:Q4892529 .
  ?s p:P1215 ?st .
  ?st wikibase:rank ?rank .
}}'''
    open('tools/_tmp.rq','w').write(q)
    for attempt in range(3):
        r=subprocess.run(['curl','-sS','-A','star-map-research/0.1 (generic client)','-H','Accept: text/csv','--max-time','120','-o',f,'-w','%{http_code}','--data-urlencode','query@tools/_tmp.rq','https://query.wikidata.org/sparql'],capture_output=True,text=True)
        s=open(f).read() if os.path.exists(f) else ''
        ok=r.stdout.strip()=='200' and s.startswith('s,') and 'Thread.run' not in s
        print(a,b,r.stdout.strip(),s.count('\n')-1,'ok' if ok else 'INCOMPLETE'); sys.stdout.flush()
        time.sleep(35)
        if ok: break
