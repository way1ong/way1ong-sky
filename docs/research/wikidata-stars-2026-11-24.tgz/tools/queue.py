import glob,os,subprocess,sys,time
for f in sorted(glob.glob('queue/*.rq')):
    out=f[:-3]+'.csv'
    for attempt in range(14):
        if os.path.exists(out):
            s=open(out,errors='replace').read()
            if s[:1] in 'scx' and '<html' not in s[:200] and 'Thread.run' not in s and 'timeout' not in s[:60]: break
        r=subprocess.run(['curl','-sS','-A','star-map-research/0.1 (generic client)','-H','Accept: text/csv','--max-time','120','-o',out,'-w','%{http_code}','--data-urlencode','query@'+f,'https://query.wikidata.org/sparql'],capture_output=True,text=True)
        s=open(out,errors='replace').read() if os.path.exists(out) else ''
        ok=r.stdout.strip()=='200' and 'Thread.run' not in s
        print(time.strftime('%H:%M:%S'),f,r.stdout.strip(),s.count('\n'),'ok' if ok else 'retry'); sys.stdout.flush()
        time.sleep(75)
        if ok: break
        if r.stdout.strip()=='504' and attempt>=2: break
print('done')
