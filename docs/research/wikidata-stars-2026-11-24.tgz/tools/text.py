import re,html,sys
s=open(sys.argv[1],encoding='utf-8',errors='replace').read()
s=re.sub(r'<script.*?</script>|<style.*?</style>','',s,flags=re.S)
s=re.sub(r'<(br|p|li|tr|h\d|hr|div)[^>]*>','\n',s,flags=re.I)
s=html.unescape(re.sub(r'<[^>]+>',' ',s)); s=re.sub(r'[ \t]+',' ',s); s=re.sub(r'\n\s*\n+','\n',s)
pat=sys.argv[2] if len(sys.argv)>2 else None
for l in s.split('\n'):
    if not pat or re.search(pat,l,flags=re.I): print(l.strip()[:600])
